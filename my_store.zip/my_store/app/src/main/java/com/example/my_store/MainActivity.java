package com.example.my_store;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ImageView intent_image;
    ImageView intent_review;
    ImageView intent_report;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intent_image=(ImageView)findViewById(R.id.Receipt_image);

        intent_image.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Toast.makeText(getApplicationContext(),"액티비티 전환",Toast.LENGTH_LONG).show();
            Intent intent= new Intent(MainActivity.this,sellActivity.class);


        startActivity(intent);
        }
    });

        intent_review=(ImageView)findViewById(R.id.Review_image);
        intent_review.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"액티비티 전환",Toast.LENGTH_LONG).show();
                Intent intent= new Intent(MainActivity.this,reviewActivity.class);

                startActivity(intent);
            }
        });


        intent_report=(ImageView)findViewById(R.id.Report_image);
        intent_report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"액티비티 전환",Toast.LENGTH_LONG).show();
                Intent intent= new Intent(MainActivity.this,reportActivity.class);

                startActivity(intent);
            }
        });


    }
    public boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()){

            case android.R.id.home:{
                finish();
                return true;
            }

        }
        return super.onOptionsItemSelected(item);

    }

//    public void displayToast(String message){
//        Toast.makeText(getApplication(),message,Toast.LENGTH_SHORT).show();
//
//    }
//
//
//    public void showsell(View view){
//
//        displayToast(getString(R.string.Receipt));
//    }
//
//    public void showreview(View view){
//
//        displayToast(getString(R.string.Review));
//    }
//
//    public void showreport(View view){
//
//        displayToast(getString(R.string.Report));
//    }
}
package com.example.my_store;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class sellActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sell);

    }
}
